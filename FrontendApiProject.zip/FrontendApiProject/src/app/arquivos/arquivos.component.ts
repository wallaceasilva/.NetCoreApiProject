import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Byte } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { Arquivo } from '../Models/arquivo';
import { ArquivoService } from '../services/arquivo.service';

@Component({
  selector: 'app-arquivos',
  templateUrl: './arquivos.component.html',
  styleUrls: ['./arquivos.component.css']
})
export class ArquivosComponent implements OnInit {

  uploadedFiles: any[] = [];
  arquivoUpload: Byte[] = [];

  arquivos: Arquivo[] = [];
  colunas: any[] = [];
  menuItens: MenuItem[] = [];
  displayMessageNovo: boolean = false;
  arq = {} as Arquivo;

  arquivoSelecionado = {} as Arquivo;

  constructor(private arquivoService: ArquivoService, 
              private messageService: MessageService,
              private confirmService: ConfirmationService)
  { }

  getArqs() {
    this.arquivoService.getArquivos().subscribe(
      (result: Arquivo[]) => {
        console.log(result);
        this.arquivos = result;
      },
      error => {
        console.log(error);
      }
    );
  }

  onUpload(event: any) {
    for(let file of event.files) {
        this.uploadedFiles.push(file);

        this.arq.nome = file.name;
        this.arq.dtCriacao = new Date();
        this.arquivoUpload = this.uploadedFiles;
        this.arq.file = this.arquivoUpload;
    }
  }

  showDialogMessage(editar: boolean){
    if (editar) {
      if (this.arquivoSelecionado.id > -1) {
        this.arq = this.arquivoSelecionado;
      }else{
        this.messageService.add({severity : 'warn', summary: "Advertencia!", detail: "Por favor selecione um registro!"});
        return;
      }
    } else {
      this.arq = {} as Arquivo;
    }
    this.displayMessageNovo = true;
  }

  salvar() {
    this.arquivoService.salvar(this.arq).subscribe(
      (result: any) => {
        let novoArq = result as Arquivo;
        this.validarArquivo(novoArq);
        this.messageService.add({
          severity: 'success',
          summary: "Resultado",
          detail: "Arquivo salvo com sucesso!"
        });
        this.displayMessageNovo = false;
      },
      error => {
        console.log(error);
      }
    );
  }

  deletar(){
    if (this.arquivoSelecionado.id == -1) {
      this.messageService.add({severity : 'warn', summary: "Advertencia!", detail: "Por favor selecione um registro!"});
      return;
    }
    this.confirmService.confirm({
      message: "Deseja excluir este arquivo?",
      accept : () =>{
        this.arquivoService.deletar(this.arquivoSelecionado.id).subscribe(
          (result:any) =>{
            this.messageService.add({ severity: 'success', summary: "Resultado", detail: "Arquivo excluido com sucesso!" });
            this.deleteObject(result.id);
          }
        )
      }
    })
  }

  deleteObject(id:number){
    let index = this.arquivos.findIndex((e) => e.id == id);
    if(index != -1){
      this.arquivos.splice(index, 1);
    }
  }

  validarArquivo(pArquivo: Arquivo){
    let index = this.arquivos.findIndex((e) => e.id == pArquivo.id);

    if(index != -1){
      this.arquivos[index] = pArquivo;
    }else{
      this.arquivos.push(pArquivo);
    }
  }

  ngOnInit(): void {
    this.getArqs();
    this.colunas = [
      {field: "id", header: "ID"},
      {field: "nome", header: "Nome do Arquivo"},
      {field: "dtCriacao", header: "Data"},
      {field: "file", header: "Arquivo"},
    ];

    this.menuItens = [
      { label: 'Novo', icon: 'pi pi-fw pi-plus', command: ()=> this.showDialogMessage(false)},
      { label: 'Editar', icon: 'pi pi-fw pi-pencil', command: ()=> this.showDialogMessage(true)},
      { label: 'Excluir', icon: 'pi pi-fw pi-times', command: ()=> this.deletar()}
    ];
  }
}
